<?php


class Config {


    const SMTP_HOST = 'smtp.mailtrap.io';


    const SMTP_PORT = 2525;

    const SMTP_USER = '3094146a7d4624';

    const SMTP_PASSWORD = '3b6f67d72d0b41';



}
